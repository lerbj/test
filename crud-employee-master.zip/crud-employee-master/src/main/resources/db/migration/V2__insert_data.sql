INSERT INTO employee VALUES
  ('aa1','naruto','naruto@gmail.com'),
  ('aa2','sasuke','naruto1@gmail.com'),
  ('aa3','sakura','naruto2@gmail.com'),
  ('aa4','kakasi','naruto3@gmail.com'),
  ('aa5','tsunade','naruto4@gmail.com'),
  ('aa6','jiraya','naruto5@gmail.com'),
  ('aa7','sino','naruto6@gmail.com');

INSERT INTO s_roles VALUES
('adm','ROLE_ADMIN'),('stf','ROLE_STAFF');

INSERT INTO s_users VALUES
('u001','didik','$2a$10$T0lWqk.pk2guoCxhCqPS9.HHxX6TSIL2559Gk7qNIF0hODKtTXda.',true),('u002','adi','$2a$10$T0lWqk.pk2guoCxhCqPS9.HHxX6TSIL2559Gk7qNIF0hODKtTXda.',true);

INSERT INTO s_user_role VALUES
('u001','adm'),('u001','stf'),('u002','stf');


