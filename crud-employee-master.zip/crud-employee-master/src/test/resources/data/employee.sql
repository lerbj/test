delete from employee;
INSERT INTO employee VALUES
  ('aa1','naruto','naruto@gmail.com'),
  ('aa2','naruto2','naruto1@gmail.com'),
  ('aa3','naruto3','naruto@2gmail.com');